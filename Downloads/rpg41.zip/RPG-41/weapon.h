#include <iostream>
#include <vector>
using namespace std;

// class thar holds a weapon name and how much damage it does
class Weapon{
	public:
	string weapon;
	int damage;
};
