//class that holds the current coordinates of a player
class Move {
	public:
		unsigned int row = 0;
		unsigned int column = 0;
};
