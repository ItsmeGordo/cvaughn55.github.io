//Christian Vaughn Cole Freitas
#include <iostream>
#include <cmath>
#include <ctime>

using namespace std;

//Function to assign a color to a string based on a given int
void wireColorPicker (string &wirecolor, int wire) {
	if (wire == 1) {
		wirecolor = "red";
	}

	else if (wire == 2) {
		wirecolor = "green";
	}

	else if (wire == 3) {
		wirecolor = "blue";
	}

	else if (wire == 4) {
		wirecolor = "black";
	}

	else if (wire == 5) {
		wirecolor = "white";
	}

	else if (wire == 6) {
		wirecolor = "yellow";
	}
}

//Function to take in movement provided my user and update coordinants and distance walked in the game
void movement (string directionOfTravel, int& x, int& y, int& totalWalked) {
	if (directionOfTravel == "up" && y < 5) {
		y++;
		totalWalked++;
	} else if (directionOfTravel == "right" && x < 5) {
		x = x + 1;
		totalWalked++;
	} else if (directionOfTravel == "down" && y > 1) {
		y--;
		totalWalked++;
	} else if (directionOfTravel == "left" && x > 1) {
		x = x - 1;
		totalWalked++;
	}

//else if statement to prevent the user from going out of bounds and telling them why they cant move that way
	else if ( (directionOfTravel == "right" && x == 5) || (directionOfTravel == "up" && y == 5) || (directionOfTravel == "down" && y == 1) || (directionOfTravel == "left" && x == 1)) {
		cout << "You can't go through the mountains." << endl;
	} else if (directionOfTravel == "examine" || directionOfTravel == "location") {

	}

	else {
		cout << "Invalid Command!" << endl;
	}
}

int main() {
//instructions, player data, and world generation things are before while loop, so they dont get reset after every move.
	const std::string red ("\033[1;31m");
	const std::string green ("\033[1;32m");
	const std::string cyan ("\033[1;36m");
	const std::string reset ("\033[0m");
	cout << green << "               ______                  _   " << red << "______                 _     " << endl;
	cout << green << "               |  ___|                | |  " << red << "| ___ \\               | |   " << endl;
	cout << green << "               | |_ ___  _ __ ___  ___| |_ " << red << "| |_/ / ___  _ __ ___ | |__ " << endl;
	cout << green << "               |  _/ _ \\| '__/ _ \\/ __| __|" << red << "| ___ \\/ _ \\| '_ ` _ \\| '_ \\" << endl;
	cout << green << "               | || (_) | | |  __/\\__ \\ |_ " << red << "| |_/ / (_) | | | | | | |_) |" << endl;
	cout << green << "               \\_| \\___/|_|  \\___||___/\\__|" << red << "\\____/ \\___/|_| |_| |_|_.__/ " << endl;
	cout << reset;

	cout << "\n------------------------------------------------ Goals ---------------------------------------------------------------------" << endl;
	cout << "Successfully defuse the bomb by travelling the world to obtain the defusal instructions to win the game" << endl;
	cout << "You loose if you difuse the bomb incorrectly, or if it takes you more than 50 moves to difuse the bomb" << endl;
	cout << "Please type all commands in lowercase" << endl;
	cout << "---------------------------------------------------------------------------------------------------------------------------\n" << endl;

	cout << "----------------------------------------------- Commands -------------------------------------------------------------------" << endl;
	cout << "To move type: up, down, left, right. To look at a sign, or defuse the bomb type: examine. To obtain your X and Y coordinates \ntype location." << endl;
	cout << "Any other needed commands will be provided while attemping to solve the respected puzzle." << endl;
	cout << "----------------------------------------------------------------------------------------------------------------------------\n" << endl;

	int x = 3; //starting position for the player
	int y = 3;
	int totalWalked = 0;

	//variables dealing with the puzzles puzzle
	int keyPosx = 0;
	int keyPosy = 0;
	int puzzle2Posx = 0;
	int puzzle2Posy = 0;
	int puzzle3Posx = 0;
	int puzzle3Posy = 0;
	//booleans to check if a puzzle has been completed
	bool hasClueOne = false;
	bool hasClueTwo = false;
	bool hasClueThree = false;
	string riddleOneAns;
	string riddleTwoAns;
	string riddleThreeAns;
	//ints to decide answers for defusing the bomb
	int wire1 = 0;
	int wire2 = 0;
	int wire3 = 0;

	//generates starting point for puzzles and makes sure puzzles are not at starting point
	srand (time (NULL));
	keyPosx = (rand() % 5) + 1;
	keyPosy = (rand() % 5) + 1;

	while (true) {
		if ( (keyPosx == 3 && keyPosy == 3) || (keyPosx == puzzle2Posx && keyPosy == puzzle2Posy) || (keyPosx == puzzle3Posx && keyPosy == puzzle3Posy)) {
			keyPosx = (rand() % 5) + 1;
			keyPosy = (rand() % 5) + 1;
		}

		else break;
	}

	//generate random number for Wire123
	wire1 = (rand() % 6) + 1;
	wire2 = (rand() % 6) + 1;
	wire3 = (rand() % 6) + 1;

	while (true) {
		if (wire1 == wire2 || wire1 == wire3) {
			wire1 = (rand() % 6) + 1;
		} else break;
	}

	while (true) {
		if (wire2 == wire3 || wire2 == wire1) {
			wire2 = (rand() % 6) + 1;
		} else break;
	}

	while (true) {
		if (wire3 == wire2 || wire3 == wire1) {
			wire3 = (rand() % 6) + 1;
		} else break;
	}


	/*strings to store the correct wires to cut to win, and call to function that sets
	 the string to the right color based on random number generated above*/
	string wire1Color;
	string wire2Color;
	string wire3Color;
	wireColorPicker (wire1Color, wire1);
	wireColorPicker (wire2Color, wire2);
	wireColorPicker (wire3Color, wire3);

	// generates the location for the 2nd puzzle
	puzzle2Posx = (rand() % 5) + 1;
	puzzle2Posy = (rand() % 5) + 1;

	while (true) {
		if ( (puzzle2Posx == 3 && puzzle2Posy == 3) || (puzzle2Posx == keyPosx && puzzle2Posy == keyPosy) || (puzzle2Posx == puzzle3Posx && puzzle2Posy == puzzle3Posy)) {
			puzzle2Posx = (rand() % 5) + 1;
			puzzle2Posy = (rand() % 5) + 1;
		}

		else break;
	}

	//geerate location for 3rd puzzle
	puzzle3Posx = (rand() % 5) + 1;
	puzzle3Posy = (rand() % 5) + 1;

	while (true) {
		if ( (puzzle3Posx == 3 && puzzle3Posy == 3) || (puzzle3Posx == keyPosx && puzzle3Posy == keyPosy) || (puzzle3Posx == puzzle2Posx && puzzle3Posy == puzzle2Posy)) {
			puzzle3Posx = (rand() % 5) + 1;
			puzzle3Posy = (rand() % 5) + 1;
		} else break;
	}

	//variables for bomb defusal challenge
	string cutWire;
	// Fancy game over, and You won messages.
	string gameOver1 = " _____                        _____                _ ";
	string gameOver2 = "|  __ \\                      |  _  |              | |";
	string gameOver3 = "| |  \\/ __ _ _ __ ___   ___  | | | |_   _____ _ __| |";
	string gameOver4 = "| | __ / _` | '_ ` _ \\ / _ \\ | | | \\ \\ / / _ \\ '__| |";
	string gameOver5 = "| |_\\ \\ (_| | | | | | |  __/ \\ \\_/ /\\ V /  __/ |  |_|";
	string gameOver6 = " \\____/\\__,_|_| |_| |_|\\___|  \\___/  \\_/ \\___|_|  (_)";

	string youWin1 = "  ___    ___ ________  ___  ___          ___       __   ___  ________      ";
	string youWin2 = " |\\  \\  /  /|\\   __  \\|\\  \\|\\  \\        |\\  \\     |\\  \\|\\  \\|\\   ___  \\    ";
	string youWin3 = " \\ \\  \\/  / | \\  \\|\\  \\ \\  \\\\\\  \\       \\ \\  \\    \\ \\  \\ \\  \\ \\  \\\\ \\  \\   ";
	string youWin4 = "  \\ \\    / / \\ \\  \\\\\\  \\ \\  \\\\\\  \\       \\ \\  \\  __\\ \\  \\ \\  \\ \\  \\\\ \\  \\  ";
	string youWin5 = "   \\/  /  /   \\ \\  \\\\\\  \\ \\  \\\\\\  \\       \\ \\  \\|\\__\\_\\  \\ \\  \\ \\  \\\\ \\  \\ ";
	string youWin6 = " __/  / /      \\ \\_______\\ \\_______\\       \\ \\____________\\ \\__\\ \\__\\\\ \\__\\";
	string youWin7 = "|\\___/ /        \\|_______|\\|_______|        \\|____________|\\|__|\\|__| \\|__|";
	string youWin8 = "\\|___|/                                                                    ";

//Actual gameplay starts here
	while (true) {

		//message for starting point(location of the final challenge.
		if (x == 3 && y == 3) {
			cout << "You see a bomb in the middle of 4 intersecting pathways." << endl;
		}


		string directionOfTravel = " "; // string to store what direction to travel
		cout << "\n>";
		cin >> directionOfTravel;
		movement (directionOfTravel, x, y, totalWalked);

		// Tells the user all wire colors on the bomb, and if they cut a wrong wire game over, but if correct they move on to next wire.
		if (directionOfTravel == "examine" && (x == 3 && y == 3)) {
			cout << "You approach the bomb and notice 6 wires.(red, green, blue, black, white, and yellow) Which will you cut first?" << endl;
			cout << "\n>";
			cin >> cutWire;

			if (cutWire == wire1Color) {
				cout << "The bomb did not explode, but the timer still counts down. Which wire shall you cut next?" << endl;
				cout << "\n>";
				cin >> cutWire;

				if (cutWire == wire2Color) {
					cout << "Another Safe wire cut, but one more to go. Which one will it be?" << endl;
					cout << "\n>";
					cin >> cutWire;

					if (cutWire == wire3Color) {
						cout << "The timer has stopped. You sucessfully difused the bomb!" << endl;
						cout << cyan << youWin1 << endl;
						cout << youWin2 << endl;
						cout << youWin3 << endl;
						cout << youWin4 << endl;
						cout << youWin5 << endl;
						cout << youWin6 << endl;
						cout << youWin7 << endl;
						cout << youWin8 << reset << "\n" << endl;
						break;
					}

					else {
						cout << "You cut the wrong wire, and blew up" << endl;
						cout << red << gameOver1 << endl;
						cout << gameOver2 << endl;
						cout << gameOver3 << endl;
						cout << gameOver4 << endl;
						cout << gameOver5 << endl;
						cout << gameOver6 << reset << "\n" << endl;
						break;
					}
				}

				else {
					cout << "You cut the wrong wire, and blew up" << endl;
					cout << red << gameOver1 << endl;
					cout << gameOver2 << endl;
					cout << gameOver3 << endl;
					cout << gameOver4 << endl;
					cout << gameOver5 << endl;
					cout << gameOver6 << reset << "\n" << endl;
					break;
				}
			}

			else {
				cout << "You cut the wrong wire, and blew up" << endl;
				cout << red << gameOver1 << endl;
				cout << gameOver2 << endl;
				cout << gameOver3 << endl;
				cout << gameOver4 << endl;
				cout << gameOver5 << endl;
				cout << gameOver6 << reset << "\n" <<  endl;
				break;
			}

		}
		//end of final challenge

		//message if player lands on a puzzle space
		if ( (x == keyPosx && y == keyPosy) || (x == puzzle2Posx && y == puzzle2Posy) || (x == puzzle3Posx && y == puzzle3Posy)) {
			cout << "A sign stands in the middle of the intersecting paths" << endl;
		}

		//If player lands on coords with the puzzle and types examine it launches puzzle, but if puzzle has been completed it outputs the clue.
		if (x == keyPosx && y == keyPosy && hasClueOne == false && directionOfTravel == "examine") {
			cout << "A riddle is posted to the sign. Answer this riddle to gain a clue" << endl;
			while (true) {
				cout << "Puzzle #1 \nAlone I am 24th, With a friend I am 20. Another friend I am unclean. \nWhat am I?" << endl;
				cout << "\n>";
				cin >> riddleOneAns;
				if (riddleOneAns == "x") {
					hasClueOne = true;
					break;
				} else {
					cout << "Wrong answer. Please try again" << endl;
				}
			}
			cout << "The riddle has been sucessfully answered.\nThe sign now reads \n1st clue: " << wire1Color << endl;
		}

		else if (x == keyPosx && y == keyPosy && hasClueOne == true && directionOfTravel == "examine") {
			cout << "You already visited this sign post. It reads: \n1st clue: " << wire1Color << endl;
		}

		//start of the second puzzle
		if (x == puzzle2Posx && y == puzzle2Posy && hasClueTwo == false && directionOfTravel == "examine") {
			cout << "A Puzzle is attached to the sign. Solve it to gain a clue" << endl;
			while (true) {
				cout << "Puzzle #2 \nWhat number should replace the ? \n16, 06, 68, 88, ?, 98" << endl;
				cout << "\n>";
				cin >> riddleTwoAns;
				if (riddleTwoAns == "87") {
					hasClueTwo = true;
					break;
				} else {
					cout << "Wrong answer. Please try again" << endl;
				}
			}
			cout << "Puzzle complete! \nThe sign now reads \n2nd clue: " << wire2Color << endl;
		}

		else if (x == puzzle2Posx && y == puzzle2Posy && hasClueTwo == true && directionOfTravel == "examine") {
			cout << "The sign reads: \n2nd clue: " << wire3Color << endl;
		}

		//start of 3rd puzzle
		if (x == puzzle3Posx && y == puzzle3Posy && hasClueThree == false && directionOfTravel == "examine") {
			cout << "The sign has a puzzle posted to it. Solve it to recieve a clue" << endl;
			while (true) {
				cout << "Puzzle #3 \nWhat is the 20th prime number?" << endl;
				cout << "\n>";
				cin >> riddleThreeAns;
				if (riddleThreeAns == "71") {
					hasClueThree = true;
					break;
				} else {
					cout << "Wrong answer. Please try again" << endl;
				}
			}
			cout << "Puzzle complete! \nThe sign now reads \n3rd clue: " << wire3Color << endl;
		}

		else if (x == puzzle3Posx && y == puzzle3Posy && hasClueThree == true && directionOfTravel == "examine") {
			cout << "The sign reads: \n3rd clue: " << wire3Color << endl;
		}

		//messages that are generated to describe the landscape to the player so they know which directions they can travel
		if ( ( (x != keyPosx && y != keyPosy) || (x != puzzle2Posx && y != puzzle2Posy) || (x != puzzle3Posx && y != puzzle3Posy)) && ( (x == 2 && (y == 2 || y ==  3 || y ==  4)) || (x == 3 && (y == 2 || y ==  4)) || (x == 4 && (y == 2 || y ==  3 || y ==  4)))) {
			cout << "You are surrounded by trees, but small paths lead in all 4 directions" << endl;
		}

		else if ( ( (x != keyPosx && y != keyPosy) || (x != puzzle2Posx && y != puzzle2Posy) || (x != puzzle3Posx && y != puzzle3Posy)) && (x == 1 && (y == 2 || y == 3 || y == 4))) {
			cout << "You notice a giant range of mountains to the West." << endl;
		}

		else if ( ( (x != keyPosx && y != keyPosy) || (x != puzzle2Posx && y != puzzle2Posy) || (x != puzzle3Posx && y != puzzle3Posy)) && (x == 5 && (y == 2 || y == 3 || y == 4))) {
			cout << "You notice a giant range of mountains to the East." << endl;
		}

		else if ( ( (x != keyPosx && y != keyPosy) || (x != puzzle2Posx && y != puzzle2Posy) || (x != puzzle3Posx && y != puzzle3Posy)) && (y == 5 && (x == 2 || x == 3 || x == 4))) {
			cout << "You notice a giant range of mountains to the North." << endl;
		}

		else if ( ( (x != keyPosx && y != keyPosy) || (x != puzzle2Posx && y != puzzle2Posy) || (x != puzzle3Posx && y != puzzle3Posy)) && (y == 1 && (x == 2 || x == 3 || x == 4))) {
			cout << "You notice a giant range of mountains to the South." << endl;
		}

		else if (x == 1 && y == 1) {
			cout << "Mountains tower over you in the South and West." << endl;
		}

		else if (x == 5 && y == 1) {
			cout << "Mountains tower over you in the South and East." << endl;
		}

		else if (x == 1 && y == 5) {
			cout << "Mountains lie in the North and West" << endl;
		}

		else if (x == 5 && y == 5) {
			cout << "Mountains lie in the North and East" << endl;
		}
		//end of describing map landscapei

		if (directionOfTravel == "location") {
			cout << "X: " << x << " Y: " << y << endl;
			continue;
		}

		//game over if player takes move than 100 steps
		if (totalWalked > 50) {
			cout << "The bomb exploded, and burnt the whole forest down before you could defuse it." << endl;
			cout << red << gameOver1 << endl;
			cout << gameOver2 << endl;
			cout << gameOver3 << endl;
			cout << gameOver4 << endl;
			cout << gameOver5 << endl;
			cout << gameOver6 << reset << "\n" <<  endl;
			break;
		}

		cout << "Moves: " << totalWalked << endl;
	}
}
